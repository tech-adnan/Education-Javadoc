/**
 * The {@code EducationBoard} class represents an educational board with its details.
 * This class contains information about the board's name, the date it was established,
 * the resolution number that established it, and the date of the gazette notification.
 * It also provides methods to access and display this information.
 *
 * <p>Author: Adnan Shaikh</p>
 * <p>Roll No: 03</p>
 * <p>Start Date: 17/07/2024</p>
 * <p>Modified Date: 24/07/2024</p>
 */
public class EducationBoard {
    /**
     * Name of the Education Board
     * <p>Specifies the name of the Education Board.</p>
    * */
    public String name;
    /**
     * Established Date
     * <p>Shows The Established Date Of The Education Board.</p>
     * */
    public String establishedDate;
    /**
     * Resolution Number
     * <p>Shows The Resolution Number Of The Education Board.</p>
     * */
    public String resolutionNumber;
    /**
     * Gazette Notification Date
     * <p>Shows The Date Of When Gazette Notification Is Received.</p>
     * */
    public String gazetteNotificationDate;

    /**
     * Constructs an {@code EducationBoard} instance with the specified details.
     *
     * @param name The name of the educational board.
     * @param establishedDate The date when the board was established.
     * @param resolutionNumber The resolution number associated with the establishment of the board.
     * @param gazetteNotificationDate The date of the gazette notification for the establishment of the board.
     */
    public EducationBoard(String name, String establishedDate, String resolutionNumber, String gazetteNotificationDate) {
        this.name = name;
        this.establishedDate = establishedDate;
        this.resolutionNumber = resolutionNumber;
        this.gazetteNotificationDate = gazetteNotificationDate;
    }

    /**
     * Returns the name of the educational board.
     *
     * @return The name of the board.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the date when the educational board was established.
     *
     * @return The established date of the board.
     */
    public String getEstablishedDate() {
        return establishedDate;
    }

    /**
     * Returns the resolution number associated with the establishment of the educational board.
     *
     * @return The resolution number of the board.
     */
    public String getResolutionNumber() {
        return resolutionNumber;
    }

    /**
     * Returns the date of the gazette notification for the establishment of the educational board.
     *
     * @return The gazette notification date of the board.
     */
    public String getGazetteNotificationDate() {
        return gazetteNotificationDate;
    }

    /**
     * Displays the information about the educational board to the console.
     * This includes the board's name, establishment date, resolution number, and gazette notification date.
     */
    public void getBoardInfo() {
        System.out.println("Board Name: " + name);
        System.out.println("Established Date: " + establishedDate);
        System.out.println("Resolution Number: " + resolutionNumber);
        System.out.println("Gazette Notification Date: " + gazetteNotificationDate);
    }
}
